from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render, redirect
from django_tables2 import RequestConfig

from interview.models import Questions, Answers, QuestionForm, AnswersForm, AnswersTable, Category

from interview.models import Scores

user = None


def question(request, question_id):
    if request.method == 'GET':
        query_question = Questions.objects.get(pk=question_id)
        query_answer = Answers.objects.filter(question=query_question)
        question_form = QuestionForm(instance=query_question)
        return render(request, 'interview/question.html',
                      {'question_form': question_form, 'query_answer': query_answer, "question_id": question_id})
    if request.method == 'POST' and QuestionForm(request.POST).is_valid():
        question_to_update = Questions.objects.get(pk=question_id)
        question_to_update.Question = request.POST['Question']
        question_to_update.category = Category.objects.get(pk=request.POST['category'])
        question_to_update.save()
        return redirect('question', question_id=question_id)


def delete_answer(request, answer_id, question_id):
    if request.method == 'GET':
        Answers.objects.get(pk=answer_id).delete()
        return redirect('question', question_id=question_id)


def delete_question(request, question_id):
    if request.method == 'GET':
        question_to_delete = Questions.objects.get(pk=question_id)
        Answers.objects.filter(question=question_to_delete).delete()
        Questions.delete(question_to_delete)
        return get_all_answer(request)


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        User.objects.create_user(username, email, password)
    return render(request, 'interview/register.html')


def index(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        global user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return render(request, 'interview/landing.html', {'username': user})
        else:
            messages.add_message(request, messages.ERROR, 'Wrong password or user')
    return render(request, 'interview/index.html')


def add_question(request):
    global user
    question = QuestionForm()
    answers_1 = AnswersForm()
    if user is not None and request.user.is_staff:
        if request.method == 'GET':
            return render(request, 'interview/add_question.html',
                          {'username': user, 'question': question, 'answers_1': answers_1})

        if request.method == 'POST' and QuestionForm(request.POST).is_valid():
            new_question = QuestionForm(request.POST)
            new_question.save()
            return render(request, 'interview/add_question.html',
                          {'username': user, 'question': question, 'answers_1': answers_1})

        if request.method == 'POST' and AnswersForm(request.POST).is_valid():
            new_answers = AnswersForm(request.POST)
            new_answers.save()
            return render(request, 'interview/add_question.html',
                          {'username': user, 'question': question, 'answers_1': answers_1})
    else:
        return render(request, 'interview/landing.html', {'username': user})


@login_required
def landing(request):
    if user is not None:
        if request.method == 'POST':
            return render(request, 'interview/landing.html', {'username': user})
        else:
            return render(request, 'interview/landing.html', {'username': user})
    else:
        return render(request, "interview/index.html", {'username', user})


def logout(request):
    global user
    if user is not None:
        user = None
    return redirect('index')


def questions(request):
    if user is not None:
        if request.method == 'GET':
            return get_all_answer(request)


def get_all_answer(request):
    list_of_questions = Answers.objects.all()
    table_of_questions = AnswersTable(list_of_questions, template_name="django_tables2/bootstrap4.html")
    RequestConfig(request, paginate={'per_page': 10}).configure(table_of_questions)
    return render(request, 'interview/questions_list.html', {'table_of_questions': table_of_questions})


def java_questions(request):
    if user is not None:
        if request.method == 'GET':
            answers = Answers.objects.select_related()
            questions = Questions.objects.filter(category__in=[1, 3])
            return render(request, 'interview/questions.html', {'answers': answers, 'questions': questions})
        if request.method == 'POST':
            scores = Scores(user_email=user.email, score=request.POST.get('score'))
            scores.save()
            return render(request, 'interview/landing.html')
