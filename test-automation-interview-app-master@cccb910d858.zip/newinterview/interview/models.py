from dataclasses import dataclass

from django.db import models

# Create your models here.
from django.forms import ModelForm
import django_tables2 as tables
from django_tables2 import A


class Category(models.Model):
    category = models.CharField(max_length=255)

    def __str__(self):
        return self.category


class Questions(models.Model):
    Question = models.CharField(max_length=10000)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, default=None)

    def __str__(self):
        return self.Question


class QuestionForm(ModelForm):
    class Meta:
        model = Questions
        fields = ['id', 'Question', 'category']


class Answers(models.Model):
    question = models.ForeignKey(Questions, on_delete=models.PROTECT, default=None)
    answer = models.CharField(max_length=10000)
    score = models.IntegerField()


class AnswersTable(tables.Table):
    edit = tables.LinkColumn("question", text="Edit", args=[A("question_id")])

    class Meta:
        model = Answers
        fields = ['id', 'question', 'answer', 'score', 'edit']


class AnswersForm(ModelForm):
    class Meta:
        model = Answers
        fields = ['question', 'answer', 'score']


class Scores(models.Model):
    user_email = models.EmailField()
    score = models.DecimalField(max_digits=2, decimal_places=0)
