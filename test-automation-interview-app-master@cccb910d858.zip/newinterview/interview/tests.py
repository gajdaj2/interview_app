from django.test import TestCase
from .models import Scores, Category, Answers, Questions


# Create your tests here.

class ScoresTestCase(TestCase):
    def setUp(self) -> None:
        Scores.objects.create(user_email='kuba@wp.pl', score=20)

    def test_get_data_from_score_object(self) -> None:
        score = Scores.objects.get(user_email='kuba@wp.pl')
        self.assertEqual(score.score, 20)


class CategoryTestCase(TestCase):

    def setUp(self) -> None:
        Category.objects.create(category='Test Category')

    def test_get_data_from_Category_object(self) -> None:
        category = Category.objects.get(category='Test Category')
        self.assertEqual(category.category, 'Test Category')


class AnswerTestCase(TestCase):
    def setUp(self) -> None:
        Category.objects.create(category="Test category")
        Questions.objects.create(Question='Test Question',
                                 category_id=Category.objects.get(category='Test category').pk)
        question = Questions.objects.get(Question__contains='Test Question')
        Answers.objects.create(question=question, answer="Very good answer", score=0)

    def test_get_data_from_Answer_object(self):
        answer = Answers.objects.get(score=0, answer='Very good answer')
        self.assertEqual(answer.score, 0)
