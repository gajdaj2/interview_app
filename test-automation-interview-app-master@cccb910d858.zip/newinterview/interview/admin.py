from django.contrib import admin

from .models import Scores, Category, Questions, Answers

# Register your models here.
admin.site.register(Scores)
admin.site.register(Category)
admin.site.register(Questions)
admin.site.register(Answers)
