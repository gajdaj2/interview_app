### Pre-requsits before start using Interview App:  


2. Execute command and check installation: 
   a. `python --version` 
   b. `pip --version`

# Installation process 


### 3. Go to folder \newinterview and execute command: 
   ``` pip install -r requirements.txt ```
   This will install all dependecies please remember that file requirements.txt is in mDoctor folder
### 4. Execute command: 
   ``` python manage.py runserver ```
   
### You will see :
    Watching for file changes with StatReloader
    Performing system checks...


### Interview Instruction:    
### Open link http://127.0.0.1:8000 You will see welcome page
    a. Go to page http://127.0.0.1:8000/register/ and register your account
    b. Go to Login page and login there
    c. From Test Menu select Java Test Automation
    d. Answer question and clik button Check result and then click Save Button 
    e. You can do printscreen too if you want.
    f. Open IntelliJ and create new Maven Project 
    e. Create tests automation for application Interview using your best technical knowledge. 
    f. Test should contains point from "a" to "d" of this instruction
    g. You can use all tools, technics you know it's up to you. 
    h. After all create repository on github and save all result there with printscreen from point "e".
    i. Link to repository send to Nordea contact or outsourcing company. 
 
     
  
    
    

### Have fun  